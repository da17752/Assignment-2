import tpot as tp   
from sklearn.model_selection import train_test_split
import pandas as pd 
import numpy as np 
import os
import random
from PIL import Image
from tpot import TPOTClassifier
from tpot import TPOTRegressor
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.neighbors import DistanceMetric

#		The libraries below are for the possible pipelines export by Tpot

#		it deopends on the type of classifier Tpot find it is the best

#		In this example we used Rabndom Forest

from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import BernoulliNB
from sklearn.pipeline import make_pipeline, make_union
from tpot.builtins import StackingEstimator
from sklearn.preprocessing import FunctionTransformer
from copy import copy

##								Initialize parameters
images=[]
output=[]
sample=30
path="/Users/diegoalbuja/Desktop/images_background/"

##								Defining Functions 

def classifier ():

	#	Function to learn a classifier using TPOT

	#	It will rerturn the accuracy of the classifier and the best classifier Tpot could find

	tpot = TPOTClassifier(verbosity=2, max_time_mins=5, population_size=30)
	
	tpot.fit(images_train, output_train)
	accuracy = tpot.score(images_test, output_test)

	print ("Accuracy of TPOT:")
	print (accuracy)

	tpot.export('classifier.py')

	return accuracy

def f_metric (images,output):

	#	Function to define a metric based on the Tpot classifier to be used on knn

	return accuracy

def knn ():

	#	KNN based on the classifier of Tpot

	#	It will return the accuracy at predicting, the predicition and the actual outcome

	DistanceMetric.get_metric('pyfunc', func=f_metric)
	KNN = KNeighborsClassifier(n_neighbors=5, algorithm='auto', metric=f_metric)

	KNN.fit(images_train, output_train)
	knn_prediction = KNN.predict(images_test)

	print("Accuracy of KNN:")
	print(accuracy_score(output_test, knn_prediction))

	print("Predictions KNN:")
	print(knn_prediction)

	print("Actual outcome:")
	print(output_test)

def new_classifier():

	#	Funtion that revisit Tpot classifier with class_weight=balanced 

	#	Basing on the pipeline giving by Tpot, with the parameters it generated, we add the class_weight=balanced

	#	Type of classifier used: RandomForest

	exported_pipeline = \
	RandomForestClassifier(bootstrap=True, class_weight="balanced", criterion="gini",\
	 max_features=0.9500000000000001, min_samples_leaf=16, min_samples_split=14, n_estimators=100)

	exported_pipeline.fit(images_train, output_train)
	results = exported_pipeline.predict(images_test)

	print("Accuracy of new Classifier:")
	print(accuracy_score(output_test, results))

	print("Predictions new Classifier:")
	print(results)

	print("Actual outcome:")
	print(output_test)
	

##										MAIN
##								Generating Sample

#Accesing folders of language

direction= random.choice(os.listdir(path))

for i in range (0, sample):
#Accesing type of character
	character1=random.choice(os.listdir(path+direction))
	character2=random.choice(os.listdir(path+direction))

#    Calculating similarity 
	if character2==character1:
		similarity=0
	else:
		similarity=1


#    First Image

#selecting image through folders
	drawing1=random.choice(os.listdir(path+direction+"/"+character1))

#Accesing the actual image
	draw1=Image.open(path+direction+"/"+character1+"/"+drawing1)

#Accesign disposition of pixels and having them as a list
	d1=list(draw1.getdata())


#     Second Image
	drawing2=random.choice(os.listdir(path+direction+"/"+character2))
	draw2=Image.open(path+direction+"/"+character2+"/"+drawing2)
	d2=list(draw2.getdata())


# adding information into an array

	description=(np.array([d1,d2])).ravel()
	images.append(description)
	
	response=np.array([similarity])
	output.append(response)

# converting the list into an array
images=np.asarray(images)
output=np.asarray(output)
output=output.ravel()

#	Splitting data set into trainning and testing sets
images_train, images_test, output_train, output_test = train_test_split(images, output,train_size=0.70, test_size=0.30)

#	Running TPOT classifier
accuracy=classifier()

#	Running Knn based on TPOT classifier
knn()

#	Revisiting Tpot classifier with class_weight=balanced
new_classifier()












