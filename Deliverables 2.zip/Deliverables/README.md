# CE888- Final Assignment
# Link of the github Repository: https://github.com/da17752/Assignment-2
#LInk to Data: https://github.com/brendenlake/omniglot